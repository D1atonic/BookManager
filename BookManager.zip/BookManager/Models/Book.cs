﻿namespace BookManager.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Book")]
    public partial class Book
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Required(ErrorMessage = "ID không được trống!")]
        [Range(1000, 1000000, ErrorMessage = "Giá sách nằm trong khoảng từ 1 đến 1000")]
        public int ID { get; set; }


        [Required(ErrorMessage = "Tiêu đề không được trống!")]
        [StringLength(255, ErrorMessage ="Tiêu đề không vượt quá 100 ký tự!")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Nội dung không được trống!")]
        [StringLength(255)]
        public string Description { get; set; }

        [Required(ErrorMessage = "Tên tác giả không được trống!")]
        [StringLength(255, ErrorMessage = "Tên tác giả không quá 30 ký tự!")]
        public string Author { get; set; }

        [Required(ErrorMessage = "Hình ảnh không được trống!")]
        public string Images { get; set; }

        [Required(ErrorMessage = "Giá tiền không được trống!")]
        [Range(1000, 1000000, ErrorMessage = "Giá sách nằm trong khoảng từ 1000 đến 1000000")]
        public int Price { get; set; }
    }
}
